package com.example.ACSocioambiental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcSocioambientalApplicationTests {

	@Test
	void contextLoads() {
	}

}
